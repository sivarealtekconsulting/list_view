

export default function AshickDetailedView() {
    return (
        <div>
            Hi Hellow
        </div>
    )
}